<?php

namespace Plugins\Surveys;

class SurveysPlugin
{
    public function register()
    {
    }
}