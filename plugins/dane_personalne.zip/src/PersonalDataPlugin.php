<?php

namespace Plugins\PersonalData;

class PersonalDataPlugin
{
    public function register()
    {
    }
}