<?php

namespace Plugins\Faq;

class FaqPlugin
{
    public function register()
    {
    }
}